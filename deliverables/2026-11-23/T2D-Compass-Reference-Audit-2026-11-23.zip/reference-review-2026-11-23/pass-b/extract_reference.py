"""Independent source-first annotation pass B, derived from FIELD_DICTIONARY only.

Reads raw registry snapshots and the wholly blank annotation template. This file
does not read/import any application mapping code, generated cards, traces,
other annotation passes, or model outputs. Fixed prose is contract text, not a
registry quotation. The annotated files require subsequent human review.
"""
from pathlib import Path
import copy
import hashlib
import json
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
REPO = ROOT / "submission/T2D-compass"
DATA = REPO / "data/type2diabetes"
OUT = Path(__file__).resolve().parent
AUTHOR = "assistant_source_b"
INTERPRETATION = "Eligibility criteria only; not actual enrolled-participant characteristics."


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def at(value, dotted):
    for part in dotted.split("."):
        if not isinstance(value, dict) or part not in value:
            return None
        value = value[part]
    # Dictionary: a missing or empty-string scalar maps to null. All observed
    # nonmissing values are type-checked separately below; no fallback inference.
    return None if isinstance(value, str) and not value.strip() else copy.deepcopy(value)


def obj(raw, fields):
    return {target: at(raw, source) for target, source in fields.items()}


def array(raw, path, fields):
    entries = at(raw, path)
    if entries is None:
        return None
    assert isinstance(entries, list), (path, type(entries).__name__)
    assert all(isinstance(item, dict) for item in entries), path
    return [obj(item, fields) for item in entries]


P = "protocolSection."
SINGLE = {
    "identity.nct_id": P + "identificationModule.nctId",
    "identity.title": P + "identificationModule.briefTitle",
    "identity.conditions": P + "conditionsModule.conditions",
    "status.study_type": P + "designModule.studyType",
    "status.overall_status": P + "statusModule.overallStatus",
    "status.completion_date": P + "statusModule.completionDateStruct.date",
    "status.completion_date_type": P + "statusModule.completionDateStruct.type",
    "results.has_results": "hasResults",
}
DESIGN = {
    "phases": "phases",
    "allocation": "designInfo.allocation",
    "intervention_model": "designInfo.interventionModel",
    "masking": "designInfo.maskingInfo.masking",
    "who_masked": "designInfo.maskingInfo.whoMasked",
}
POPULATION = {
    "eligibility_criteria": "eligibilityCriteria",
    "healthy_volunteers": "healthyVolunteers",
    "sex": "sex",
    "minimum_age": "minimumAge",
    "maximum_age": "maximumAge",
}
ARMS = {"label": "label", "type": "type", "description": "description", "intervention_names": "interventionNames"}
INTERVENTIONS = {"name": "name", "type": "type", "description": "description", "arm_group_labels": "armGroupLabels", "other_names": "otherNames"}
OUTCOMES = {"measure": "measure", "description": "description", "time_frame": "timeFrame"}

# These observations were made by inspecting the raw protocol modules, before
# reference generation. They are source issues, not inferred application errors.
OBSERVATIONS = {
    "NCT03244800": {
        "arms": "Keep source label 'PLacebo Cohort 2' exactly, including capitalization. Four source arms; do not reorder by intervention.",
        "interventions": "Placebo armGroupLabels order is PLacebo Cohort 2 then Placebo Cohort 1, unlike arm array order. Both names and association order are preserved.",
        "primary_outcomes": "Two source primary outcomes are both labeled Cohort 1. Do not invent Cohort 2 outcomes; retain complete distinct timeframes.",
    },
    "NCT05790681": {
        "design": "Allocation is explicit NA and masking is NONE; whoMasked is absent, so who_masked is null.",
        "population": "Structured maximumAge is 18 Years, while eligibility text says aged 10 to less than 18 years. Preserve both without adjudicating the age boundary.",
        "primary_outcomes": "All three primary pharmacokinetic outcomes are retained in source order, including the infinity and last-measurement timeframes.",
    },
    "NCT04214600": {
        "design": "Source structured masking is SINGLE and whoMasked contains PARTICIPANT. Narrative maskingDescription mentions research-team blinding; do not alter the structured extraction from narrative text.",
        "arms": "Control is NO_INTERVENTION and lacks interventionNames. Its intervention_names is null, not an empty array or an inferred follow-up intervention.",
        "population": "Structured minimumAge is 35 Years; eligibility narrative says more than 35 years. Preserve both literal values.",
    },
    "NCT01596244": {
        "design": "Source phases=[NA] and allocation=NA are explicit values; preserve them. whoMasked is absent.",
        "population": "healthyVolunteers is true. Eligibility includes diabetes, pre-diabetes, or accompanying family members; do not claim every enrolled person had T2D. Structured maximumAge is absent.",
        "status.completion_date": "Preserve the source month-precision date 2012-08; do not supply a day.",
    },
    "NCT01614769": {
        "arms": "Six crossover sequence arms are retained with their arrow characters and exact order; all four intervention names are explicitly linked to each arm.",
        "interventions": "Each of four interventions has six armGroupLabels. Their association order differs from the armGroups array and is preserved as reported.",
        "primary_outcomes": "Three distinct recovery primary outcomes all have the same reported timeframe; retain each separate measure and full description.",
    },
    "NCT02811055": {
        "population": "Source ambiguity: inclusion says age 18-30, exclusions say younger than 18 and older than 70, structured minimumAge is 18 Years and maximumAge is absent. Preserve all source text; do not resolve the discrepancy.",
        "arms": "Two crossover arms each explicitly list five intervention names; preserve shared procedures/devices and arm-specific drug names.",
        "interventions": "First four interventions are shared by both arms, then two arm-specific drugs. Preserve all six interventions; do not reduce this source to only aprepitant/placebo.",
    },
    "NCT00004266": {
        "identity.conditions": "Only Diabetic Nephropathy is present in conditions; title and eligibility mention type 2/non-insulin-dependent diabetes. Do not add a T2D condition label.",
        "status.completion_date": "Month-precision 1999-07 is ACTUAL; preserve precision.",
        "interventions": "All three intervention descriptions and otherNames are absent. Preserve nulls and exact arm associations, including reversed simvastatin arm-label order.",
        "primary_outcomes": "outcomesModule and primaryOutcomes are absent. Expected null is intentional; narrative objectives do not populate this array.",
    },
    "NCT00000620": {
        "design": "Structured intervention model is FACTORIAL and masking is NONE with whoMasked absent. Lipid-arm descriptions say double blind; preserve the structured value and narrative text without harmonizing them.",
        "arms": "Six arms span glycemia, blood-pressure and lipid subtrials. Preserve exact lower-case label spelling and all three paired intervention associations.",
        "interventions": "All three intervention objects retain complete otherNames lists (15, 19 and 1 names) and both associated arm labels; do not normalize drug names.",
        "primary_outcomes": "Three separate primary outcomes have respective timeframes 4.9 years, 4.7 years, 4.7 years. Preserve the full first description including early discontinuation text; no numerical results are inferred.",
        "status.completion_date": "Completion is 2012-12, distinct from primary completion 2009-06. Preserve month precision.",
    },
    "NCT00001870": {
        "status.completion_date": "Source reports 2004-12 with no completion-date type. Do not infer ACTUAL from COMPLETED status.",
        "status.completion_date_type": "completionDateStruct.type is absent; annotated null is intentional.",
        "design": "phases=[PHASE2] is present. allocation, interventionModel and maskingInfo are absent; allocation, intervention_model, masking and who_masked are null.",
        "enrollment": "Count 150 is present but enrollmentInfo.type is absent. Do not call it actual or estimated.",
        "population": "healthyVolunteers is true; structured minimumAge and maximumAge are absent despite different age ranges in diabetic and volunteer eligibility text. Do not fill ages from narrative.",
        "arms": "armGroups is absent. Expected null is intentional, not an empty array and not an inferred arm from the study title.",
        "interventions": "The sole structured intervention name is Acetylcholine despite the Vitamin C title. description, armGroupLabels and otherNames are absent; preserve these nulls and flag source ambiguity for human review.",
        "primary_outcomes": "outcomesModule and primaryOutcomes are absent; expected null is intentional.",
    },
    "NCT00001723": {
        "identity.conditions": "Conditions are Diabetes Mellitus, Hypertension, Metabolic Disease, Obesity, Sleep Apnea Syndrome. T2D appears in keywords and eligibility, not the conditions array; do not add it.",
        "population": "Structured healthyVolunteers=false is preserved although eligibility text includes healthy control children/adolescents. T2D is one example qualifying comorbidity, not required for every participant. Preserve this source ambiguity.",
        "arms": "Source arm order is Placebo then Orlistat, while intervention order is Orlistat then Placebo. Match by explicit source labels, never by index.",
        "interventions": "Preserve source typo 'weight los program' and exact otherNames strings, including 'Xenical (orlistat)capsules'.",
        "status.completion_date": "Keep month-precision 2011-10 and ACTUAL type.",
    },
}


def missing_leaf_paths(value, prefix=""):
    found = []
    if value is None:
        return [prefix]
    if isinstance(value, dict):
        for key, item in value.items():
            found.extend(missing_leaf_paths(item, f"{prefix}.{key}" if prefix else key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            found.extend(missing_leaf_paths(item, f"{prefix}[{index}]"))
    return found


def associations(protocol):
    ai = protocol.get("armsInterventionsModule", {})
    arms = ai.get("armGroups")
    interventions = ai.get("interventions")
    arm_labels = {arm.get("label") for arm in arms or []}
    unresolved = []
    for index, intervention in enumerate(interventions or []):
        for label in intervention.get("armGroupLabels", []):
            if label not in arm_labels:
                unresolved.append({"intervention_index": index, "arm_label": label})
    missing = [f"armGroups[{i}].interventionNames" for i, arm in enumerate(arms or []) if "interventionNames" not in arm]
    missing += [f"interventions[{i}].armGroupLabels" for i, item in enumerate(interventions or []) if "armGroupLabels" not in item]
    expected_names = {item.get("type", "").title() + ": " + item.get("name", "") for item in interventions or []}
    unmatched = []
    for index, arm in enumerate(arms or []):
        for name in arm.get("interventionNames", []):
            if name not in expected_names:
                unmatched.append({"arm_index": index, "intervention_name": name})
    return {"arm_count": len(arms) if arms is not None else None,
            "intervention_count": len(interventions) if interventions is not None else None,
            "unresolved_reported_arm_labels": unresolved,
            "reported_arm_intervention_names_without_structured_match": unmatched,
            "missing_association_arrays": missing,
            "association_inference_used": False}


def main():
    manifest_file = DATA / "manifest.json"
    template_file = DATA / "review/reference-annotations.json"
    dictionary_file = REPO / "docs/FIELD_DICTIONARY.md"
    manifest = read(manifest_file)
    template = read(template_file)
    assert len(manifest) == len(template["records"]) == 10
    assert all(not field["annotated"] and field["expected"] is None
               for record in template["records"] for field in record["fields"])
    created = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    result = {"schema_version": template["schema_version"], "created_at": created,
              "author": AUTHOR, "reviewed_by": [], "review_status": "pending_human_review",
              "method": "Independent source-first extraction from ten frozen raw ClinicalTrials.gov JSON files and FIELD_DICTIONARY.md; no mapper, cards, traces or other annotator output read.",
              "instructions": template["instructions"], "records": []}
    checks = {"schema_version": "1.0", "created_at": created, "author": AUTHOR,
              "reviewed_by": [], "review_status": "pending_human_review",
              "input_hashes": {str(path.relative_to(ROOT)).replace('\\', '/'): digest(path) for path in (manifest_file, template_file, dictionary_file)},
              "scope": "Frozen snapshot extraction accuracy only; not live registry verification, clinical validation, model evaluation, or human approval.",
              "heldout_use": "Evaluation only. Candidate/scoring frozen by parent before this pass; no implementation or prompt changes made.",
              "records": []}
    for item, blank in zip(manifest, template["records"]):
        source_file = DATA / item["file"]
        actual_hash = digest(source_file)
        assert actual_hash == item["sha256"], item["nct_id"]
        raw = read(source_file)
        protocol = raw["protocolSection"]
        nct = raw["protocolSection"]["identificationModule"]["nctId"]
        assert nct == item["nct_id"] == blank["nct_id"]
        assert blank["split"] == item["split"]
        assert blank["snapshot_sha256"] == actual_hash
        values = {key: at(raw, path) for key, path in SINGLE.items()}
        values["design"] = obj(protocol["designModule"], DESIGN)
        values["enrollment"] = obj(protocol["designModule"].get("enrollmentInfo", {}), {"count": "count", "type": "type"})
        values["population"] = obj(protocol.get("eligibilityModule", {}), POPULATION)
        values["population"]["interpretation"] = INTERPRETATION
        values["arms"] = array(raw, P + "armsInterventionsModule.armGroups", ARMS)
        values["interventions"] = array(raw, P + "armsInterventionsModule.interventions", INTERVENTIONS)
        values["primary_outcomes"] = array(raw, P + "outcomesModule.primaryOutcomes", OUTCOMES)
        assert set(values) == {field["path"] for field in blank["fields"]}
        assert len(values) == 14
        assert isinstance(values["results.has_results"], bool)
        assert isinstance(values["enrollment"]["count"], int) and not isinstance(values["enrollment"]["count"], bool)
        assert isinstance(values["population"]["healthy_volunteers"], bool)
        locations = {key: [path] for key, path in SINGLE.items()}
        locations["design"] = [P + "designModule." + path for path in DESIGN.values()]
        locations["enrollment"] = [P + "designModule.enrollmentInfo.count", P + "designModule.enrollmentInfo.type"]
        locations["population"] = [P + "eligibilityModule." + path for path in POPULATION.values()]
        locations["arms"] = [P + "armsInterventionsModule.armGroups[*]." + path for path in ARMS.values()]
        locations["interventions"] = [P + "armsInterventionsModule.interventions[*]." + path for path in INTERVENTIONS.values()]
        locations["primary_outcomes"] = [P + "outcomesModule.primaryOutcomes[*]." + path for path in OUTCOMES.values()]
        rec = copy.deepcopy(blank)
        rec.update(author=AUTHOR, reviewed_by=[], review_status="pending_human_review")
        relative = str(source_file.relative_to(ROOT)).replace('\\', '/')
        for field in rec["fields"]:
            key = field["path"]
            notes = ["Direct raw-source value; source array order and full text preserved where applicable."]
            nulls = missing_leaf_paths(values[key], key)
            if nulls:
                notes.append("Not reported in this record: " + ", ".join(nulls) + ". Nulls are intentional annotations.")
            if key == "population":
                notes.append("interpretation is the fixed application contract statement, not registry text; no enrolled-sample inference.")
            if key == "results.has_results":
                notes.append("Explicit registry boolean retained; results availability does not supply numeric results or clinical conclusions.")
            if key in OBSERVATIONS.get(nct, {}):
                notes.append(OBSERVATIONS[nct][key])
            field.update(expected=values[key], annotated=True,
                         source_location="; ".join(relative + "#$." + path for path in locations[key]),
                         note=" ".join(notes))
        result["records"].append(rec)
        source_check = {"nct_id": nct, "split": item["split"], "source_file": relative,
                        "source_url": item["source_url"], "capture_time": item["retrieved_at"],
                        "expected_sha256": item["sha256"], "actual_sha256": actual_hash,
                        "hash_matches": True, "identifier_matches_manifest": True,
                        "annotated_groups": 14, "reviewed_by": [], "review_status": "pending_human_review",
                        "source_locations_populated": True,
                        "intentional_null_paths": missing_leaf_paths(values),
                        "completion_date": values["status.completion_date"],
                        "completion_date_type": values["status.completion_date_type"],
                        "enrollment": values["enrollment"],
                        "primary_outcome_count": len(values["primary_outcomes"]) if values["primary_outcomes"] is not None else None,
                        "has_results": values["results.has_results"],
                        "association_checks": associations(protocol),
                        "source_observations": OBSERVATIONS[nct]}
        checks["records"].append(source_check)
    checks["summary"] = {"records": 10, "development_records": 6, "heldout_records": 4,
                         "field_groups": 140, "annotated_groups": 140, "raw_hashes_match": 10,
                         "human_reviewed_records": 0, "human_approved_records": 0,
                         "estimated_completion_dates": 0, "estimated_enrollments": 0,
                         "missing_completion_date_types": 1, "missing_enrollment_types": 1,
                         "missing_primary_outcome_arrays": 2, "missing_arm_arrays": 1,
                         "results_posted": 5, "results_not_posted": 5}
    for name, value in (("reference-annotations.json", result), ("source-checks.json", checks)):
        (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    seal = {"sealed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "author": AUTHOR, "status": "sealed_before_comparison_with_candidate_or_other_annotation_pass",
            "reviewed_by": [], "review_status": "pending_human_review",
            "files": {name: digest(OUT / name) for name in ("reference-annotations.json", "source-checks.json", "extract_reference.py")},
            "independence_attestation": "Pass B was authored from raw source snapshots and the field dictionary. No application mapping/service code, generated cards, model traces, other annotator expected values, or trial outputs were read. All 140 groups were completed before sealing."}
    (OUT / "seal.json").write_text(json.dumps(seal, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"summary": checks["summary"], "sealed_files": seal["files"]}, indent=2))


if __name__ == "__main__":
    main()

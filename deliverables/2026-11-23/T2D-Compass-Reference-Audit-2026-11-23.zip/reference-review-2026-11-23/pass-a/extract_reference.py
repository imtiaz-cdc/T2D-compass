"""Assistant source-first annotations: only raw snapshots + documented contract.

This file does not import or invoke application code, and does not read cards,
traces, scores, or another annotator's output. Expected values follow the field
dictionary; they are assistant-prepared references pending human review.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'submission/T2D-compass/data/type2diabetes'
OUT = Path(__file__).resolve().parent
DOC = ROOT / 'submission/T2D-compass/docs/FIELD_DICTIONARY.md'
AUTHOR = 'assistant_source_a'
INTERPRETATION = 'Eligibility criteria only; not actual enrolled-participant characteristics.'
NOW = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def write(name: str, data) -> None:
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2,
                                     allow_nan=False) + '\n', encoding='utf-8')


def lookup(raw, pointer: str):
    value = raw
    for key in pointer.lstrip('/').split('/'):
        key = key.replace('~1', '/').replace('~0', '~')
        if isinstance(value, dict) and key in value:
            value = value[key]
        elif isinstance(value, list) and key.isdigit() and int(key) < len(value):
            value = value[int(key)]
        else:
            return False, None
    return True, value


def source_path(pointer: str) -> str:
    value = '$'
    for key in pointer.lstrip('/').split('/'):
        value += f'[{key}]' if key.isdigit() else '.' + key
    return value


REVIEW = {
    'NCT03244800': {
        'population': 'Eligibility requires T2DM with BMI 27-40 and other conditions; this does not establish actual participant characteristics. Structured maximumAge is 130 Years and is preserved as written.',
        'arms': 'Preserve the source capitalization PLacebo Cohort 2 and the four-arm order; do not infer associations from index order.',
        'interventions': 'Placebo armGroupLabels are PLacebo Cohort 2 then Placebo Cohort 1, distinct from arm-array order; preserve the reported labels. otherNames are absent.',
        'primary_outcomes': 'Both primary outcomes are Cohort 1 measures. Preserve both descriptions and the complete distinct timeframes; do not substitute secondary outcomes or results-table measures.',
    },
    'NCT05790681': {
        'design': 'allocation=NA is explicit and remains NA. whoMasked is absent; masking=NONE is reported.',
        'population': 'Pediatric eligibility text says 10 to less than 18, while structured maximumAge is 18 Years. Preserve both without resolving the endpoint ambiguity. Enrollment is not evidence about each participant age.',
        'primary_outcomes': 'Three distinct pharmacokinetic primary outcomes and their full timeframes are retained; infinity and last-measurement timeframes are registry wording, not invented follow-up duration.',
    },
    'NCT04214600': {
        'identity.conditions': 'Both Type 2 Diabetes and Depression labels are retained. Labels and depression-screening criteria do not establish diagnoses for all enrolled participants.',
        'design': 'The phase enum NA is explicit. Preserve structured masking=SINGLE and whoMasked=[PARTICIPANT]; the separate maskingDescription is not one of the five design reference keys.',
        'population': 'Eligibility includes T2D and BDI screening range 11-30 with exclusions. Text says aged more than 35 while minimumAge is 35 Years; retain both without adjudicating.',
        'arms': 'Control is explicitly NO_INTERVENTION and has no interventionNames property; expected intervention_names is null, not an empty array or an invented CBT link.',
    },
    'NCT01596244': {
        'status.completion_date': 'Partial date 2012-08 is preserved; no day is invented.',
        'design': 'Both phases=[NA] and allocation=NA are explicit. whoMasked is absent and masking=NONE is reported.',
        'population': 'healthyVolunteers=true is explicit. Eligibility permits diabetes, pre-diabetes, or bringing a diabetic/pre-diabetic family member; do not label the whole enrolled population as T2D. maximumAge is absent. Text over 18 and structured 18 Years are preserved.',
        'primary_outcomes': 'The one primary outcome is Weight (kg); retain the complete baseline, intervention and post-intervention timeframe.',
    },
    'NCT01614769': {
        'population': 'Eligibility is clinically confirmed T2DM with other health and treatment restrictions; does not identify actual participant characteristics.',
        'arms': 'Six crossover sequence arms remain distinct in source order. All four explicit interventionNames are retained for every arm.',
        'interventions': 'All six armGroupLabels per intervention are preserved in the source association order, which differs from the arm array; do not assign a single arm by index.',
        'primary_outcomes': 'All three recovery outcomes and their descriptions are retained, each with From 1 to 180 minutes post hypoglycemic clamp.',
    },
    'NCT02811055': {
        'identity.conditions': 'Both Type 2 Diabetes and Hypertension are retained as condition labels.',
        'population': 'Source conflicts are retained: inclusion says ages 18-30, exclusion says younger than 18 and older than 70, structured maximumAge is absent. Inclusion no treatment/no anomaly language coexists with exclusion of subjects without diabetes or with normal blood pressure. Human relevance review is needed; do not repair the registry text.',
        'interventions': 'The source lists biological, procedure, device and drug interventions. Shared test procedures link to both arms and each drug links to its named arm; preserve all six interventions.',
    },
    'NCT00004266': {
        'identity.conditions': 'Only Diabetic Nephropathy is a condition label. Do not insert a T2D label from title or eligibility into the conditions array.',
        'status.completion_date': 'Partial date 1999-07 is preserved without adding a day.',
        'population': 'Eligibility specifies non-insulin-dependent diabetes, albuminuria and recruitment from named American Indian populations. These are eligibility text, not verified enrolled characteristics; maximumAge is absent.',
        'interventions': 'Descriptions and otherNames are absent for the three interventions. Keep explicit armGroupLabels; do not move arm descriptions into intervention descriptions.',
        'primary_outcomes': 'The source has no outcomesModule/primaryOutcomes. Expected null is an intentional completed annotation, not unreviewed or an empty array. Do not infer primary outcomes from the title, description or other study aims.',
    },
    'NCT00000620': {
        'identity.conditions': 'Seven condition labels are preserved in the reported order; the list does not establish that each person has every listed comorbidity.',
        'status.completion_date': 'Partial date 2012-12 is preserved without adding a day.',
        'design': 'Preserve structured FACTORIAL, NONE, and absent whoMasked. Lipid arm descriptions separately say double blind; do not overwrite the structured field with subtrial details.',
        'enrollment': '10251 ACTUAL is whole-study enrollment, not a denominator for each subtrial or outcome analysis.',
        'population': 'Age-dependent cardiovascular eligibility is preserved verbatim; not every eligible person necessarily had prior CVD.',
        'arms': 'Six arms are organized across Glycemia, BP and Lipid trials. Preserve labels, descriptions and associations rather than treating array neighbors as cross-trial comparators.',
        'interventions': 'Preserve all source otherNames, including apparent naming/spelling anomalies, and explicit two-arm associations for each intervention. No clinical correction is made.',
        'primary_outcomes': 'Retain all three subtrial primary outcomes. Glycemia timeframe is 4.9 years and BP/Lipid are each 4.7 years. Preserve the Glycemia description of therapy discontinuation and subsequent follow-up without converting it to a new effectiveness claim.',
    },
    'NCT00001870': {
        'identity.conditions': 'Historical non-insulin-dependent labels are preserved; do not rename them from keywords or title.',
        'status.completion_date': 'Partial date 2004-12 is preserved.',
        'status.completion_date_type': 'completionDateStruct.type is absent. Do not infer ACTUAL from completed status.',
        'design': 'Only PHASE2 is available among reference design values. allocation, interventionModel, maskingInfo/masking and whoMasked are absent and intentionally annotated null.',
        'enrollment': 'Count 150 is present but enrollment type is absent. Do not call it actual or estimated.',
        'population': 'healthyVolunteers=true is explicit. Text includes diabetic subjects aged 18-65 and vitamin C-deficient volunteers aged 18-35. Structured minimumAge and maximumAge are absent; do not fill them from prose or stdAges.',
        'arms': 'armGroups is absent. Expected arms=null; do not infer an arm from the single intervention or narrative.',
        'interventions': 'Only Acetylcholine DRUG is reported. Description, armGroupLabels and otherNames are absent. Do not replace with Vitamin C based on the title or infer association.',
        'primary_outcomes': 'outcomesModule/primaryOutcomes is absent. Expected null is intentionally annotated; do not infer endpoints from title or descriptive study text.',
    },
    'NCT00001723': {
        'identity.conditions': 'Five broad condition labels are retained; no explicit Type 2 Diabetes condition label is added from keywords or eligibility.',
        'status.completion_date': 'Partial date 2011-10 is preserved.',
        'population': 'Pediatric obesity eligibility allows any of several obesity-related comorbidities; T2D is only one example and is not established for all participants. Preserve structured healthyVolunteers=false despite eligibility text also including healthy control children. Structured ages are 12-17 Years.',
        'interventions': 'Preserve source wording weight los and Xenical (orlistat)capsules without editorial repair. Explicit arm labels determine associations despite intervention array order differing from arm array order.',
        'primary_outcomes': 'The primary endpoint is Change in BMI Standard Deviation Score with baseline to 6 months; do not substitute glycemic outcomes because this is a T2D evaluation set.',
    },
}

manifest_path = BASE / 'manifest.json'
blank_path = BASE / 'review/reference-annotations.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
blank = json.loads(blank_path.read_text(encoding='utf-8'))
assert len(manifest) == len(blank['records']) == 10
assert all(not f['annotated'] for r in blank['records'] for f in r['fields'])
manifest_by_id = {r['nct_id']: r for r in manifest}
checks = []
source_files = []
records = []

for record in blank['records']:
    ident = record['nct_id']
    entry = manifest_by_id[ident]
    path = BASE / entry['file']
    raw_bytes = path.read_bytes()
    digest = sha(raw_bytes)
    assert digest == entry['sha256'] == record['snapshot_sha256'], ident
    raw = json.loads(raw_bytes)
    assert raw['protocolSection']['identificationModule']['nctId'] == ident
    source_files.append({'nct_id': ident, 'split': entry['split'],
                         'source_file': str(path.relative_to(ROOT)).replace('\\', '/'),
                         'manifest_sha256': entry['sha256'], 'observed_sha256': digest,
                         'hash_matches': True})
    current_checks = []

    def checked(pointer: str, output_path: str, kind: str = 'value'):
        exists, value = lookup(raw, pointer)
        item = {'check_id': f'{ident}:{len(current_checks) + 1:03d}',
                'nct_id': ident, 'field_path': output_path, 'source_pointer': pointer,
                'exists': exists, 'raw_value': value, 'check_kind': kind,
                'raw_value_sha256': sha(canonical(value)),
                'presence_and_value_sha256': sha(canonical({'exists': exists, 'value': value}))}
        current_checks.append(item)
        if isinstance(value, list):
            for index, element in enumerate(value):
                if not isinstance(element, (dict, list)):
                    checked(pointer + '/' + str(index), output_path + f'[{index}]', 'array_leaf')
        return value if exists else None

    def scalar(pointer: str, output_path: str, value_type=str):
        value = checked(pointer, output_path)
        if value_type is bool:
            return value if type(value) is bool else None
        if value_type is int:
            return value if type(value) is int and value >= 0 else None
        return value if isinstance(value, str) and value.strip() else None

    def strings(pointer: str, output_path: str):
        value = checked(pointer, output_path, 'array_structure')
        if not isinstance(value, list):
            return None
        return [v if isinstance(v, str) and v.strip() else None for v in value]

    def add(field_path: str, location: str, maker, note: str = ''):
        start = len(current_checks)
        expected = maker()
        relevant = current_checks[start:]
        notes = [note] if note else []
        explicit = REVIEW.get(ident, {}).get(field_path)
        if explicit:
            notes.append(explicit)
        absent = [c['source_pointer'] for c in relevant if not c['exists']]
        if absent:
            notes.append('Absent source properties are deliberately null: ' + ', '.join(absent) + '.')
        if field_path == 'results.has_results':
            notes.append('This boolean describes registry results availability only; it is not a numerical result or efficacy conclusion. False remains false.')
        if field_path == 'population':
            notes.append('interpretation is the specified application constant, not a registry quotation.')
        fields.append({'path': field_path, 'expected': expected, 'annotated': True,
                       'source_location': location, 'note': ' '.join(notes),
                       'source_checks': [c['check_id'] for c in relevant],
                       'annotation_author': AUTHOR})

    fields = []
    p = '/protocolSection/'
    scalars = [
        ('identity.nct_id', p + 'identificationModule/nctId'),
        ('identity.title', p + 'identificationModule/briefTitle'),
        ('identity.conditions', p + 'conditionsModule/conditions'),
        ('status.study_type', p + 'designModule/studyType'),
        ('status.overall_status', p + 'statusModule/overallStatus'),
        ('status.completion_date', p + 'statusModule/completionDateStruct/date'),
        ('status.completion_date_type', p + 'statusModule/completionDateStruct/type'),
    ]
    for output_path, pointer in scalars:
        add(output_path, source_path(pointer),
            lambda ptr=pointer, out=output_path: strings(ptr, out) if out == 'identity.conditions' else scalar(ptr, out))

    def design():
        base = p + 'designModule/'
        return {'phases': strings(base + 'phases', 'design.phases'),
                'allocation': scalar(base + 'designInfo/allocation', 'design.allocation'),
                'intervention_model': scalar(base + 'designInfo/interventionModel', 'design.intervention_model'),
                'masking': scalar(base + 'designInfo/maskingInfo/masking', 'design.masking'),
                'who_masked': strings(base + 'designInfo/maskingInfo/whoMasked', 'design.who_masked')}

    def enrollment():
        base = p + 'designModule/enrollmentInfo/'
        return {'count': scalar(base + 'count', 'enrollment.count', int),
                'type': scalar(base + 'type', 'enrollment.type')}

    def population():
        base = p + 'eligibilityModule/'
        return {'eligibility_criteria': scalar(base + 'eligibilityCriteria', 'population.eligibility_criteria'),
                'healthy_volunteers': scalar(base + 'healthyVolunteers', 'population.healthy_volunteers', bool),
                'sex': scalar(base + 'sex', 'population.sex'),
                'minimum_age': scalar(base + 'minimumAge', 'population.minimum_age'),
                'maximum_age': scalar(base + 'maximumAge', 'population.maximum_age'),
                'interpretation': INTERPRETATION}

    add('design', '$.protocolSection.designModule', design)
    add('enrollment', '$.protocolSection.designModule.enrollmentInfo', enrollment,
        'Preserve the source enrollment type and count independently; enrollment is not an outcome-analysis denominator.')
    add('population', '$.protocolSection.eligibilityModule; specification: population.interpretation', population)

    arrays = [
        ('arms', p + 'armsInterventionsModule/armGroups', [
            ('label', 'label', False), ('type', 'type', False),
            ('description', 'description', False), ('intervention_names', 'interventionNames', True)]),
        ('interventions', p + 'armsInterventionsModule/interventions', [
            ('name', 'name', False), ('type', 'type', False), ('description', 'description', False),
            ('arm_group_labels', 'armGroupLabels', True), ('other_names', 'otherNames', True)]),
        ('primary_outcomes', p + 'outcomesModule/primaryOutcomes', [
            ('measure', 'measure', False), ('description', 'description', False), ('time_frame', 'timeFrame', False)]),
    ]
    for output_path, pointer, key_pairs in arrays:
        def record_array(ptr=pointer, out=output_path, pairs=key_pairs):
            source = checked(ptr, out, 'array_structure')
            if not isinstance(source, list):
                return None
            result = []
            for index, _item in enumerate(source):
                result.append({dest: (strings if is_array else scalar)(
                    ptr + f'/{index}/' + key, out + f'[{index}].' + dest)
                    for dest, key, is_array in pairs})
            return result
        add(output_path, source_path(pointer), record_array,
            'Source array order and original text are preserved; absent values are not borrowed from neighboring entries.')
    add('results.has_results', '$.hasResults', lambda: scalar('/hasResults', 'results.has_results', bool))

    assert [f['path'] for f in fields] == [f['path'] for f in record['fields']]
    assert len(fields) == 14 and all(f['annotated'] for f in fields)
    records.append({**record, 'annotation_author': AUTHOR,
                    'review_status': 'pending_human_review', 'reviewed_by': [],
                    'source_hash_verified': True, 'fields': fields,
                    'review_notes': ['Assistant source-first extraction against frozen local API record; no generated card, application mapper, trace, or other pass was read.',
                                     'No clinical endorsement or human approval is asserted. Human reviewers must adjudicate relevance and preserved registry inconsistencies.']})
    checks.extend(current_checks)

# Re-resolve every recorded pointer from a fresh source read. Preserve evidence of
# absence distinctly from JSON null. This verifies locations/hashes, not clinical truth.
source_by_id = {e['nct_id']: json.loads((BASE / e['file']).read_bytes()) for e in manifest}
for check in checks:
    exists, value = lookup(source_by_id[check['nct_id']], check['source_pointer'])
    assert exists == check['exists']
    assert canonical(value) == canonical(check['raw_value'])
    assert sha(canonical(value)) == check['raw_value_sha256']
    assert sha(canonical({'exists': exists, 'value': value})) == check['presence_and_value_sha256']
    check['source_recheck_passed'] = True

annotations = {**blank, 'created_at': NOW, 'annotation_author': AUTHOR,
               'review_status': 'pending_human_review', 'reviewed_by': [],
               'method': 'Independent source-first assistant annotation from the ten hash-verified raw frozen records and FIELD_DICTIONARY.md, with record-specific source inspection. No application code, generated cards, traces, scores or other pass was consulted.',
               'human_approval': False,
               'records': records}
write('reference-annotations.json', annotations)
write('source-checks.json', {
    'schema_version': '1.0', 'created_at': NOW, 'annotation_author': AUTHOR,
    'review_status': 'pending_human_review', 'reviewed_by': [],
    'scope': '140 field-group annotations across 6 development and 4 held-out frozen records; source/hash verification, not clinical or human approval.',
    'raw_hash_verifications': source_files,
    'summary': {'records': 10, 'field_groups': 140, 'annotated_field_groups': 140,
                'development_field_groups': 84, 'heldout_field_groups': 56,
                'source_checks': len(checks), 'source_checks_passed': len(checks),
                'absent_pointer_checks': sum(not c['exists'] for c in checks),
                'all_source_hashes_match': True},
    'canonical_hash_rule': 'SHA-256 of UTF-8 JSON using ensure_ascii=false, sort_keys=true and separators=(comma,colon). raw_value_sha256 hashes raw_value; presence_and_value_sha256 hashes {exists: boolean, value: raw_value}, so missing and present null remain distinct.',
    'specification_constants': [{'field_path': 'population.interpretation', 'expected': INTERPRETATION,
                                 'origin': 'Exact application text supplied as specification; field dictionary documents this as application text, not source quotation.',
                                 'raw_source': False}],
    'checks': checks,
})
seal_inputs = [{'path': str(p.relative_to(ROOT)).replace('\\', '/'), 'sha256': sha(p.read_bytes())}
               for p in [manifest_path, blank_path, DOC]]
artifacts = [{'file': name, 'sha256': sha((OUT / name).read_bytes())}
             for name in ['reference-annotations.json', 'source-checks.json', 'extract_reference.py']]
write('seal.json', {'sealed_at': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
                   'annotation_author': AUTHOR, 'review_status': 'pending_human_review',
                   'reviewed_by': [], 'field_group_coverage': '140/140',
                   'source_hash_coverage': '10/10', 'source_checks': len(checks),
                   'application_outputs_viewed_before_seal': False,
                   'application_implementation_viewed': False,
                   'other_annotation_pass_viewed': False,
                   'heldout_usage': 'Evaluation only after parent candidate/scoring freeze; no app, source, prompt, or scoring changes made by this annotator.',
                   'input_contract_hashes': seal_inputs, 'artifacts': artifacts})
print(json.dumps({'sealed': True, 'field_groups': 140, 'records': 10,
                  'source_checks': len(checks), 'source_hashes_match': 10,
                  'annotation_sha256': artifacts[0]['sha256']}, indent=2))

"""Reconcile sealed source-only assistant annotations before viewing app output."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED_PATHS = [
    "identity.nct_id", "identity.title", "identity.conditions", "status.study_type",
    "status.overall_status", "status.completion_date", "status.completion_date_type",
    "design", "enrollment", "population", "arms", "interventions",
    "primary_outcomes", "results.has_results",
]

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def serialized(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False)

def value_hash(value):
    return hashlib.sha256(serialized(value).encode("utf-8")).hexdigest()

def write_new(name, value):
    target = ROOT / name
    with target.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return target

def main():
    frozen = json.loads((ROOT / "candidate-freeze.json").read_text(encoding="utf-8-sig"))
    repo = Path(frozen["candidate_root"])
    source_dir = repo / "data/type2diabetes"
    manifest_path = source_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    inputs = [ROOT / name / "reference-annotations.json" for name in ("pass-a", "pass-b")]
    for path in inputs:
        assert (path.parent / "seal.json").is_file(), "Source-only pass must be sealed."
    forms = [json.loads(p.read_text(encoding="utf-8-sig")) for p in inputs]
    maps = [{r["nct_id"]: r for r in form["records"]} for form in forms]
    assert all(len(m) == 10 and set(m) == {e["nct_id"] for e in manifest} for m in maps)
    checks, disagreements, records, source_integrity = [], [], [], []
    for entry in manifest:
        nct = entry["nct_id"]
        raw = source_dir / entry["file"]
        observed_hash = digest(raw)
        assert observed_hash == entry["sha256"], f"Source changed: {nct}"
        source = json.loads(raw.read_text(encoding="utf-8-sig"))
        assert source["protocolSection"]["identificationModule"]["nctId"] == nct
        source_integrity.append({
            "nct_id": nct, "split": entry["split"], "source_file": entry["file"],
            "source_url": entry["source_url"], "captured_at": entry["retrieved_at"],
            "manifest_sha256": entry["sha256"], "observed_sha256": observed_hash,
            "hash_matches": True, "record_id_matches": True,
        })
        a, b = [m[nct] for m in maps]
        for candidate in (a, b):
            assert candidate["snapshot_sha256"] == entry["sha256"]
            assert candidate["split"] == entry["split"]
            assert candidate["reviewed_by"] == [], "No human approval may be invented."
            assert candidate["review_status"] != "approved"
            assert len(candidate["fields"]) == 14
            assert {f["path"] for f in candidate["fields"]} == set(EXPECTED_PATHS)
            assert all(f["annotated"] is True and f["source_location"] for f in candidate["fields"])
        field_maps = [{f["path"]: f for f in candidate["fields"]} for candidate in (a, b)]
        final_fields = []
        for field_path in EXPECTED_PATHS:
            fa, fb = [m[field_path] for m in field_maps]
            same = serialized(fa["expected"]) == serialized(fb["expected"])
            row = {
                "nct_id": nct, "split": entry["split"], "field_group": field_path,
                "pass_a_sha256": value_hash(fa["expected"]),
                "pass_b_sha256": value_hash(fb["expected"]), "agreement": same,
                "source_location_a": fa["source_location"],
                "source_location_b": fb["source_location"],
                "source_note_a": fa.get("note", ""), "source_note_b": fb.get("note", ""),
                "resolution": "Both separate assistant source extractions agree." if same else "Unresolved; inspect source before generating app outputs.",
            }
            checks.append(row)
            if not same:
                disagreements.append({**row, "expected_a": fa["expected"], "expected_b": fb["expected"]})
            final_fields.append({
                "path": field_path, "expected": fa["expected"], "annotated": True,
                "source_location": fa["source_location"],
                "note": fa.get("note", ""),
                "assistant_cross_check": {
                    "pass_b_source_location": fb["source_location"],
                    "pass_b_note": fb.get("note", ""), "agrees": same,
                },
            })
        records.append({
            "nct_id": nct, "split": entry["split"], "source_url": entry["source_url"],
            "snapshot_sha256": entry["sha256"], "review_status": "pending_human_review",
            "reviewed_by": [], "assistant_annotation_status": "source_checked",
            "assistant_prepared_by": ["assistant_source_a", "assistant_source_b"],
            "fields": final_fields,
        })
    assert len(checks) == 140
    timestamp = datetime.now(timezone.utc).isoformat()
    reconciliation = {
        "schema_version": "1.0", "audit_date": "2026-11-23", "created_at_utc": timestamp,
        "type": "assistant_source_check_and_reconciliation",
        "scope": "Ten original frozen records; 14 configured extraction groups per record. Source-only automated passes, not independent human or clinical review.",
        "pass_inputs": [{"file": str(p.relative_to(ROOT)).replace("\\", "/"), "sha256": digest(p)} for p in inputs],
        "candidate_freeze_sha256": digest(ROOT / "candidate-freeze.json"),
        "source_manifest_sha256": digest(manifest_path),
        "source_integrity": source_integrity,
        "groups_checked": len(checks), "groups_agree": sum(r["agreement"] for r in checks),
        "disagreement_count": len(disagreements), "disagreements": disagreements,
        "group_checks": checks,
        "human_approval": "pending",
        "prior_delivery_reconciliation": [
            "November 21 Word documents report scenario passes and named scenario reviews; those claims are not reassigned to this source audit.",
            "Reviewer 2's earlier pending source-review wording conflicts with its completed source-reference statement. The November 21 delivery lacks supporting annotation artifacts.",
            "These new annotations were prepared by assistants on November 23. They do not backdate or substantiate the claimed November 21 human source-reference approval.",
        ],
        "limitations": [
            "Both extraction passes are assistants; they may share systematic errors.",
            "Source hashes establish byte integrity, not truth or clinical validity of registry claims.",
            "Missing values and internally inconsistent source statements are preserved; human interpretation remains separate.",
        ],
    }
    if disagreements:
        write_new("pre-evaluation-disagreements.json", reconciliation)
        raise SystemExit(f"{len(disagreements)} disagreements require source adjudication before evaluation")
    final = {
        "schema_version": "1.0", "created_at": timestamp, "audit_date": "2026-11-23",
        "annotation_origin": "Two separate assistant source-only extraction passes reconciled before viewing candidate app outputs.",
        "instructions": "All expected values are populated from frozen sources. Human approval is pending. Reviewers must inspect sources and resolve discrepancies before adding their own names and setting approved. Generated cards were not used as expected reference answers.",
        "human_approval": "pending", "records": records,
    }
    final_path = write_new("reference-annotations.json", final)
    reconciliation_path = write_new("source-check-reconciliation.json", reconciliation)
    write_new("reference-seal.json", {
        "sealed_at_utc": timestamp, "before_candidate_card_generation": True,
        "reference_file": final_path.name, "reference_sha256": digest(final_path),
        "reconciliation_sha256": digest(reconciliation_path),
        "candidate_freeze_sha256": digest(ROOT / "candidate-freeze.json"),
        "records": 10, "field_groups": 140, "human_approval": "pending",
    })
    print(json.dumps({"records": 10, "groups": 140, "source_hashes_matched": 10,
                      "assistant_disagreements": 0, "reference_sha256": digest(final_path)}))

if __name__ == "__main__":
    main()

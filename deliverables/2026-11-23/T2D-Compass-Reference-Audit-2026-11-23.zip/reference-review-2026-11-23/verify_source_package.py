"""Check packaged source bytes, sealed references and saved results without app execution."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import argparse
import hashlib
import json
import shutil


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def exact(value):
    return json.dumps(value, sort_keys=True, allow_nan=False)


def contained(root, relative):
    path = (root / relative).resolve()
    if Path(relative).is_absolute() or not path.is_relative_to(root):
        raise ValueError("Path leaves declared package or repository root")
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", type=Path, default=Path(__file__).parent)
    parser.add_argument("--repo-root", type=Path)
    parser.add_argument("--copy-sources", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    package = args.package_root.resolve()
    repo = args.repo_root.resolve() if args.repo_root else None
    if args.copy_sources and repo is None:
        parser.error("--copy-sources requires --repo-root")
    freeze = read(package / "candidate-freeze.json")
    seal = read(package / "reference-seal.json")
    reference = read(package / "reference-annotations.json")
    reconciliation = read(package / "source-check-reconciliation.json")
    result = read(package / "reference-evaluation.json")
    gate = read(package / "human-gated-reference-evaluation.json")
    receipt = read(package / "first-execution-started.json")
    preparation = read(package / "evaluator/preparation-checks.json")
    checks = []

    def check(label, condition, **detail):
        checks.append({"check": label, "passed": bool(condition), **detail})

    def hash_check(label, path, expected, display_path):
        observed = digest(path)
        check(label, observed == expected, file=display_path,
              expected_sha256=expected, observed_sha256=observed)

    source_root = package / "source-data"
    if args.copy_sources:
        original_manifest = repo / "data/type2diabetes/manifest.json"
        original_sources = original_manifest.parent
        manifest = read(original_manifest)
        source_root.mkdir(parents=True, exist_ok=True)
        for relative in ["manifest.json", *(entry["file"] for entry in manifest)]:
            origin = contained(original_sources, relative)
            target = contained(source_root, relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                if digest(target) != digest(origin):
                    raise ValueError("Existing packaged source differs; refusing overwrite")
            else:
                shutil.copyfile(origin, target)
    manifest_path = source_root / "manifest.json"
    manifest = read(manifest_path)
    manifest_expected = next(item["sha256"] for item in freeze["files"]
                             if item["file"] == "data/type2diabetes/manifest.json")
    hash_check("original_manifest_bytes", manifest_path, manifest_expected,
               "source-data/manifest.json")
    check("ten_sources_six_development_four_heldout",
          len(manifest) == 10 and Counter(e["split"] for e in manifest)
          == {"development": 6, "heldout": 4})
    check("ten_unique_source_identifiers", len({e["nct_id"] for e in manifest}) == 10)
    for entry in manifest:
        source = contained(source_root, entry["file"])
        hash_check("source_matches_original_manifest", source, entry["sha256"],
                   "source-data/" + entry["file"])
        check("source_identifier_matches", read(source)["protocolSection"]
              ["identificationModule"]["nctId"] == entry["nct_id"], nct_id=entry["nct_id"])
    if repo:
        for item in freeze["files"]:
            hash_check("candidate_file_unchanged", contained(repo, item["file"]),
                       item["sha256"], item["file"])
        for entry in manifest:
            hash_check("original_repository_source_unchanged",
                       contained(repo / "data/type2diabetes", entry["file"]),
                       entry["sha256"], "data/type2diabetes/" + entry["file"])
    for key, filename in [("reference_sha256", "reference-annotations.json"),
                          ("reconciliation_sha256", "source-check-reconciliation.json"),
                          ("candidate_freeze_sha256", "candidate-freeze.json")]:
        hash_check("reference_seal", package / filename, seal[key], filename)
    for pass_name in ["pass-a", "pass-b"]:
        pass_seal = read(package / pass_name / "seal.json")
        artifacts = pass_seal.get("artifacts", []) or [
            {"file": file, "sha256": value}
            for file, value in pass_seal["files"].items()]
        for item in artifacts:
            hash_check("extraction_pass_seal", package / pass_name / item["file"],
                       item["sha256"], pass_name + "/" + item["file"])
        if repo:
            for item in pass_seal.get("input_contract_hashes", []):
                relative = item["path"].removeprefix("submission/T2D-compass/")
                hash_check("pass_input_contract", contained(repo, relative),
                           item["sha256"], relative)
    for item in reconciliation["pass_inputs"]:
        hash_check("reconciliation_pass_input", contained(package, item["file"]),
                   item["sha256"], item["file"])
    for name, record in [("first_receipt", receipt), ("comparison_report", result)]:
        for key, filename in [("reference_sha256", "reference-annotations.json"),
                              ("candidate_freeze_sha256", "candidate-freeze.json")]:
            hash_check(name, package / filename, record[key], filename)
    hash_check("reconciliation_manifest", manifest_path,
               reconciliation["source_manifest_sha256"], "source-data/manifest.json")
    for name, record in [("comparison_runner", result), ("prepared_runner", preparation)]:
        hash_check(name, package / "evaluator/compare_frozen_reference.py",
                   record["runner_sha256"], "evaluator/compare_frozen_reference.py")
    by_id = {record["nct_id"]: record for record in reference["records"]}
    observed_groups = []
    for record in result["records"]:
        nct_id = record["nct_id"]
        ref = by_id[nct_id]
        check("assistant_reference_human_gate_preserved",
              ref["review_status"] == "pending_human_review" and ref["reviewed_by"] == [],
              nct_id=nct_id)
        check("fourteen_annotated_groups_with_sources",
              len(ref["fields"]) == 14 and all(f["annotated"] is True
              and f.get("source_location") and "expected" in f for f in ref["fields"]),
              nct_id=nct_id)
        card_path = contained(package, record["actual_response_file"])
        hash_check("saved_candidate_card", card_path, record["actual_response_sha256"],
                   record["actual_response_file"])
        card = read(card_path)["card"]
        expected = {f["path"]: f["expected"] for f in ref["fields"]}
        check("all_fourteen_saved_checks_present",
              len(record["checks"]) == 14
              and {c["path"] for c in record["checks"]} == set(expected), nct_id=nct_id)
        for item in record["checks"]:
            actual = card
            for part in item["path"].split("."):
                actual = actual[part]
            matches = exact(actual) == exact(expected[item["path"]])
            check("saved_comparison_recomputed", matches and item["passed"]
                  and exact(item["expected"]) == exact(expected[item["path"]])
                  and exact(item["actual"]) == exact(actual),
                  nct_id=nct_id, field_group=item["path"])
            observed_groups.append((record["split"], matches))
    check("all_140_groups_match", len(observed_groups) == 140
          and all(passed for _, passed in observed_groups))
    check("split_group_denominators", Counter(split for split, _ in observed_groups)
          == {"development": 84, "heldout": 56})
    check("reported_scores_agree", result["overall"]["matched_groups"] == 140
          and result["overall"]["passed_cards"] == 10
          and result["by_split"]["development"]["matched_groups"] == 84
          and result["by_split"]["heldout"]["matched_groups"] == 56)
    check("original_gate_expected_pending", gate["status"] == "pending_review"
          and gate["pending_cards"] == 10 and gate["compared_cards"] == 0
          and gate["compared_fields"] == 0 and gate["field_accuracy"] is None)
    check("recorded_before_after_provenance_equal",
          result["provenance_before"] == result["provenance_after"]
          and result["candidate_and_sources_unchanged"] is True)
    first_time = datetime.fromisoformat(receipt["first_execution_started_at_utc"])
    reference_time = datetime.fromisoformat(seal["sealed_at_utc"])
    check("recorded_reference_seal_precedes_first_comparison", reference_time < first_time)
    for pass_name in ["pass-a", "pass-b"]:
        pass_time = datetime.fromisoformat(read(package / pass_name / "seal.json")
                                          ["sealed_at"].replace("Z", "+00:00"))
        check("recorded_pass_seal_precedes_reference_seal", pass_time < reference_time,
              extraction_pass=pass_name)
    report = {
        "schema_version": "1.0", "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Independent byte-integrity and saved-result verification; no app execution, model calls or live requests.",
        "status": "passed" if all(c["passed"] for c in checks) else "failed",
        "checks_count": len(checks), "failed_checks": [c for c in checks if not c["passed"]],
        "source_records": 10, "source_manifest": "source-data/manifest.json",
        "candidate_files_verified_against_freeze": len(freeze["files"]) if repo else 0,
        "candidate_check": "performed" if repo else "not_requested",
        "annotated_groups": 140, "technical_agreement": {"overall": "140/140", "development": "84/84", "heldout": "56/56", "cards": "10/10"},
        "human_approval": "pending", "original_gate_status": gate["status"],
        "limitations": ["Hash checks verify recorded bytes, not clinical truth or human approval.",
                        "Recorded seal times support the documented sequence but do not independently prove how original annotations were prepared.",
                        "This covers source/reference evidence and frozen candidate files, not subsequent PDF/HTML/live-check artifacts."],
        "checks": checks,
    }
    if args.output:
        with args.output.open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(report, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
    print(json.dumps({key: report[key] for key in ["status", "checks_count", "failed_checks",
                     "source_records", "candidate_files_verified_against_freeze",
                     "technical_agreement", "human_approval", "original_gate_status"]}, indent=2))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())

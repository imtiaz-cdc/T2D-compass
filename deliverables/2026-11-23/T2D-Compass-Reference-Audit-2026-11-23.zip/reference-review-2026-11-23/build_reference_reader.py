"""Create a self-contained, read-only view of the completed reference annotations."""
import html
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def esc(value):
    return html.escape(str(value), quote=True)

def main():
    form = json.loads((ROOT / 'reference-annotations.json').read_text(encoding='utf-8'))
    pieces = ['''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>T2D Compass reference review</title>
<style>
:root{font-family:Arial,sans-serif;color:#18252b;background:#f4f6f6}body{max-width:1000px;margin:0 auto;padding:32px 22px 60px}h1{font-size:30px;margin:6px 0 16px}h2{font-size:23px}h3{font-size:16px;margin-bottom:6px}p{line-height:1.55}a{color:#075e65}nav{display:flex;gap:10px;flex-wrap:wrap;margin:25px 0}nav a{padding:7px 11px;background:#fff;border:1px solid #bfc9cc;border-radius:5px;text-decoration:none}article{background:white;border:1px solid #ccd4d6;margin:26px 0;padding:24px;border-radius:8px}article h2{margin-top:0}.meta{color:#4b5c63;font-size:14px;overflow-wrap:anywhere}details{border-top:1px solid #d4dcdf;padding:13px 0}summary{cursor:pointer;font-weight:bold}summary::marker{color:#087681}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f6f8f8;border:1px solid #dce3e5;padding:14px;font:13px/1.5 Consolas,monospace}.note{font-size:14px;color:#40535b}.status{color:#765100;font-weight:bold}.label{font-size:13px;font-weight:bold;color:#065d66;text-transform:uppercase;letter-spacing:.04em}@media print{body{background:white;padding:0}article{break-inside:avoid}nav{display:none}details>*{display:block!important}summary{list-style:none}}
</style></head><body>
<div class="label">T2D Compass · source reference audit · November 23, 2026</div>
<h1>Reference annotations for review</h1>
<p>All 140 field groups below were prepared from ten frozen ClinicalTrials.gov records in two separate assistant source-reading passes. Expand a field to inspect the exact expected value and source location. Missing values are intentional annotations, not unfinished entries.</p>
<p class="status">Assistant technical review complete. No independent human source-reference approval is claimed.</p>
<p>These are October 28 snapshots. The ClinicalTrials.gov links may show a newer record. Eligibility text describes entry criteria; completion and posted results do not establish treatment benefit. This is an extraction audit, not clinical validation.</p>
<p><a href="Reference-Audit-Summary.pdf">Audit summary PDF</a> · <a href="reference-annotations.json">Complete annotation JSON</a> · <a href="source-check-reconciliation.json">Source checks and reconciliation</a> · <a href="reference-evaluation.json">Evaluation results</a></p><nav>''']
    for record in form['records']:
        pieces.append(f'<a href="#{esc(record["nct_id"])}">{esc(record["nct_id"])}</a>')
    pieces.append('</nav>')
    for record in form['records']:
        fields = {f['path']:f for f in record['fields']}
        title = fields['identity.title']['expected']
        pieces.append(f'<article id="{esc(record["nct_id"])}"><h2>{esc(record["nct_id"])} · {esc(record["split"])}</h2><p>{esc(title)}</p>')
        pieces.append(f'<p class="meta"><a href="{esc(record["source_url"])}">ClinicalTrials.gov record</a><br>Frozen source SHA-256: {esc(record["snapshot_sha256"])}<br>Assistant source audit complete; independent human approval not claimed.</p>')
        for field in record['fields']:
            value = json.dumps(field['expected'], indent=2, ensure_ascii=False)
            pieces.append(f'<details><summary>{esc(field["path"])}</summary><pre>{esc(value)}</pre><p class="meta"><strong>Source location:</strong> {esc(field["source_location"])}</p>')
            notes = [field.get('note',''),field.get('assistant_cross_check',{}).get('pass_b_note','')]
            for note in dict.fromkeys(str(n) for n in notes if n):
                pieces.append(f'<p class="note">{esc(note)}</p>')
            pieces.append('</details>')
        pieces.append('</article>')
    pieces.append('<p class="meta">Read-only evidence viewer. No tracking, external scripts, network requests, or submission controls. Full artifacts and source copies are in this package.</p></body></html>')
    (ROOT/'Reference-Review.html').write_text(''.join(pieces),encoding='utf-8')
    print('Reference reader written for 10 records and 140 annotated groups.')

if __name__ == '__main__':
    main()

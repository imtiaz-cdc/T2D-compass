"""Synthetic-value checks only. These do not instantiate the candidate mapper."""

import unittest

from compare_frozen_reference import exact_json_equal, summarize


class ExactComparisonTests(unittest.TestCase):
    def test_distinguishes_boolean_and_numeric_values(self):
        self.assertFalse(exact_json_equal(False, 0))
        self.assertFalse(exact_json_equal(True, 1))
        self.assertTrue(exact_json_equal(False, False))

    def test_distinguishes_null_empty_and_missing(self):
        self.assertFalse(exact_json_equal(None, []))
        self.assertFalse(exact_json_equal(None, ""))
        self.assertFalse(exact_json_equal({}, {"value": None}))

    def test_preserves_array_order_and_cardinality(self):
        self.assertFalse(exact_json_equal([1, 2], [2, 1]))
        self.assertFalse(exact_json_equal([1, 1], [1]))
        self.assertTrue(exact_json_equal([None, {"x": False}], [None, {"x": False}]))

    def test_object_order_does_not_matter(self):
        self.assertTrue(exact_json_equal({"a": 1, "b": 2}, {"b": 2, "a": 1}))

    def test_scalar_types_and_text_are_exact(self):
        self.assertFalse(exact_json_equal(0, 0.0))
        self.assertFalse(exact_json_equal(0, "0"))
        self.assertFalse(exact_json_equal("x", "x "))
        self.assertTrue(exact_json_equal(0, 0))

    def test_card_failure_is_distinct_from_field_count(self):
        result = summarize(
            [
                {"status": "passed", "checks": [{"passed": True}]},
                {"status": "failed", "error": "retrieval error"},
            ]
        )
        self.assertEqual(result["compared_groups"], 1)
        self.assertEqual(result["failed_cards"], 1)
        self.assertEqual(result["full_card_accuracy"], 0.5)


if __name__ == "__main__":
    unittest.main()

"""Compare a frozen app with sealed assistant references; never confer human approval.

No candidate cards are generated until all preflight checks pass. This module's
self-tests use ordinary JSON values only, not candidate or held-out records.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import platform
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

GROUPS = [
    "identity.nct_id",
    "identity.title",
    "identity.conditions",
    "status.study_type",
    "status.overall_status",
    "status.completion_date",
    "status.completion_date_type",
    "design",
    "enrollment",
    "population",
    "arms",
    "interventions",
    "primary_outcomes",
    "results.has_results",
]


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    def invalid_constant(value):
        raise ValueError(f"Non-JSON numeric constant: {value}")

    return json.loads(
        Path(path).read_text(encoding="utf-8-sig"), parse_constant=invalid_constant
    )


def exact_json_equal(actual, expected):
    # Exactly the unchanged review.py rule: object key order does not matter;
    # array order, scalar JSON representations, whitespace in strings do matter.
    return json.dumps(actual, sort_keys=True) == json.dumps(expected, sort_keys=True)


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")


def contained(root, relative):
    relative = Path(relative)
    if relative.is_absolute():
        raise ValueError("Manifest and freeze paths must be relative")
    result = (root / relative).resolve()
    if not result.is_relative_to(root):
        raise ValueError("Path leaves the declared root")
    return result


def check_candidate(repo_root, freeze):
    files = freeze["files"]
    paths = [entry["file"] for entry in files]
    if len(paths) != len(set(paths)):
        raise ValueError("Duplicate frozen paths")
    required = {
        "src/alz_compass/review.py",
        "src/alz_compass/service.py",
        "src/alz_compass/mapping.py",
        "src/alz_compass/registry.py",
        "data/type2diabetes/manifest.json",
        "docs/FIELD_DICTIONARY.md",
    }
    if not required.issubset(paths):
        raise ValueError("Freeze omits required candidate files")
    checks = []
    for entry in files:
        actual = digest(contained(repo_root, entry["file"]))
        checks.append(
            {
                "file": entry["file"],
                "expected_sha256": entry["sha256"],
                "actual_sha256": actual,
                "matches": actual == entry["sha256"],
            }
        )
    if not all(check["matches"] for check in checks):
        raise ValueError("Frozen candidate file has changed")
    return checks


def check_sources(manifest_path):
    manifest = read_json(manifest_path)
    if not isinstance(manifest, list) or len(manifest) != 10:
        raise ValueError("Expected the frozen ten-record manifest")
    if Counter(entry["split"] for entry in manifest) != {
        "development": 6,
        "heldout": 4,
    }:
        raise ValueError("Expected six development and four held-out records")
    if len({entry["nct_id"] for entry in manifest}) != 10:
        raise ValueError("Duplicate source records")
    checks = []
    for entry in manifest:
        path = contained(manifest_path.parent, entry["file"])
        split_root = (manifest_path.parent / "public" / entry["split"]).resolve()
        if (
            not path.is_relative_to(split_root)
            or path.name != entry["nct_id"] + ".json"
        ):
            raise ValueError("Source path does not match its identifier and split")
        actual = digest(path)
        if actual != entry["sha256"]:
            raise ValueError("Source snapshot hash mismatch")
        checks.append(
            {
                "nct_id": entry["nct_id"],
                "split": entry["split"],
                "file": entry["file"],
                "source_url": entry["source_url"],
                "expected_sha256": entry["sha256"],
                "actual_sha256": actual,
                "matches": True,
            }
        )
    return manifest, checks


def check_reference(form, manifest):
    references = form.get("records")
    if not isinstance(references, list) or len(references) != 10:
        raise ValueError("Expected ten reference records")
    by_id = {record["nct_id"]: record for record in references}
    if len(by_id) != 10 or set(by_id) != {entry["nct_id"] for entry in manifest}:
        raise ValueError("Reference identifiers do not exactly match manifest")
    for entry in manifest:
        ref = by_id[entry["nct_id"]]
        if (
            ref.get("reviewed_by") != []
            or ref.get("review_status") != "pending_human_review"
        ):
            raise ValueError(
                "Assistant references must retain pending human approval and empty reviewers"
            )
        for reference_key, source_key in [
            ("split", "split"),
            ("source_url", "source_url"),
            ("snapshot_sha256", "sha256"),
        ]:
            if ref.get(reference_key) != entry[source_key]:
                raise ValueError("Reference provenance does not match manifest")
        fields = ref.get("fields", [])
        if len(fields) != 14 or {field.get("path") for field in fields} != set(GROUPS):
            raise ValueError("Reference must contain each of the fourteen groups once")
        if any(
            field.get("annotated") is not True
            or not field.get("source_location")
            or "expected" not in field
            for field in fields
        ):
            raise ValueError(
                "Each reference group needs a value, annotation flag, and source location"
            )
    return by_id


def summarize(records):
    compared = [record for record in records if "checks" in record]
    checks = [check for record in compared for check in record["checks"]]
    correct = sum(check["passed"] for check in checks)
    return {
        "expected_cards": len(records),
        "expected_groups": len(records) * 14,
        "compared_cards": len(compared),
        "compared_groups": len(checks),
        "matched_groups": correct,
        "mismatched_groups": len(checks) - correct,
        "passed_cards": sum(record["status"] == "passed" for record in records),
        "failed_cards": sum(record["status"] != "passed" for record in records),
        "field_group_accuracy": correct / len(checks) if checks else None,
        "full_card_accuracy": sum(record["status"] == "passed" for record in records)
        / len(records)
        if records
        else None,
    }


async def execute(args):
    repo = args.repo_root.resolve()
    reference_path = args.reference.resolve()
    freeze_path = args.candidate_freeze.resolve()
    output = args.output_dir.resolve()
    freeze = read_json(freeze_path)
    freeze_hash = digest(freeze_path)
    if digest(reference_path) != args.reference_sha256:
        raise ValueError("Reference does not match the supplied sealed hash")
    before_candidate = check_candidate(repo, freeze)
    manifest_path = repo / "data/type2diabetes/manifest.json"
    manifest, before_sources = check_sources(manifest_path)
    reference = read_json(reference_path)
    by_id = check_reference(reference, manifest)
    # Import the frozen source tree directly, without changing app source/config.
    sys.path.insert(0, str(repo / "src"))
    from alz_compass import review
    from alz_compass.registry import SnapshotRegistry
    from alz_compass.service import TrialService

    if (
        Path(review.__file__).resolve()
        != (repo / "src/alz_compass/review.py").resolve()
    ):
        raise ValueError("Imported evaluator is outside frozen candidate")
    if review.CORE_PATHS != GROUPS:
        raise ValueError("Frozen canonical scoring paths changed")
    started = utc_now()
    timer = time.perf_counter()
    receipt = {
        "schema_version": "1.0",
        "type": "assistant_source_reference_comparison",
        "first_execution_started_at_utc": started,
        "reference_sha256": args.reference_sha256,
        "candidate_freeze_sha256": freeze_hash,
        "data_mode": "snapshot",
        "model_calls": 0,
        "network_required": False,
        "human_approval": "pending",
        "reviewed_by": [],
        "overwrite_policy": "Exclusive file creation; first execution and cards preserved",
    }
    # Exclusive receipt prevents accidental overwrite or rerun into this result directory.
    write_new(output / "first-execution-started.json", receipt)
    report = {
        **receipt,
        "evaluation_status": "error",
        "review_status": "pending_human_review",
        "python_version": platform.python_version(),
        "runner_sha256": digest(__file__),
        "candidate_version": freeze.get("application_version"),
        "scoring_rule": freeze["scoring_rule"],
        "groups": GROUPS,
        "source_mode": "snapshot",
        "records": [],
        "provenance_before": {"candidate": before_candidate, "sources": before_sources},
        "limitations": [
            "Assistant reference comparison, not human clinical approval",
            "Measures fourteen extraction groups, not all card fields or agent answers",
            "Four held-out source records were annotated only after candidate freeze",
            "No network, hosted-app, model, effectiveness, or clinical validation claimed",
        ],
        "mapper_changed_for_evaluation": False,
    }
    try:
        registry = SnapshotRegistry(manifest_path, include_heldout=True)
        service = TrialService(registry)
        for entry in manifest:
            ref = by_id[entry["nct_id"]]
            card_started = utc_now()
            card_timer = time.perf_counter()
            actual = await service.get_trial_evidence_card(entry["nct_id"])
            card_file = f"actual-cards/{entry['split']}/{entry['nct_id']}.json"
            write_new(output / card_file, actual)
            record = {
                "nct_id": entry["nct_id"],
                "split": entry["split"],
                "status": "failed",
                "started_at_utc": card_started,
                "duration_seconds": round(time.perf_counter() - card_timer, 6),
                "actual_response_file": card_file,
                "actual_response_sha256": digest(output / card_file),
                "source_url": entry["source_url"],
                "snapshot_sha256": entry["sha256"],
                "review_status": "pending_human_review",
                "reviewed_by": [],
            }
            report["records"].append(record)
            if actual.get("status") != "ok" or actual.get("source_mode") != "snapshot":
                record["error"] = {
                    "kind": "card_retrieval_failed",
                    "returned_status": actual.get("status"),
                }
                continue
            card = actual["card"]
            if card.get("provenance", {}).get("snapshot_sha256") != entry["sha256"]:
                record["error"] = {"kind": "card_source_hash_mismatch"}
                continue
            expected_by_path = {field["path"]: field for field in ref["fields"]}
            record["checks"] = []
            for path in GROUPS:
                expected = expected_by_path[path]
                observed = review.field_value(card, path)
                record["checks"].append(
                    {
                        "path": path,
                        "passed": exact_json_equal(observed, expected["expected"]),
                        "expected": expected["expected"],
                        "actual": observed,
                        "source_location": expected["source_location"],
                    }
                )
            record["status"] = (
                "passed"
                if all(check["passed"] for check in record["checks"])
                else "failed"
            )
        await registry.aclose()
        after_candidate = check_candidate(repo, freeze)
        _, after_sources = check_sources(manifest_path)
        if (
            digest(reference_path) != args.reference_sha256
            or digest(freeze_path) != freeze_hash
        ):
            raise ValueError("Reference or candidate freeze changed during execution")
        report["provenance_after"] = {
            "candidate": after_candidate,
            "sources": after_sources,
        }
        report["candidate_and_sources_unchanged"] = (
            before_candidate == after_candidate and before_sources == after_sources
        )
        report["overall"] = summarize(report["records"])
        report["by_split"] = {
            split: summarize([r for r in report["records"] if r["split"] == split])
            for split in ["development", "heldout"]
        }
        report["by_field_group"] = {}
        for path in GROUPS:
            checks = [
                c
                for r in report["records"]
                for c in r.get("checks", [])
                if c["path"] == path
            ]
            report["by_field_group"][path] = {
                "compared": len(checks),
                "matched": sum(c["passed"] for c in checks),
                "mismatched": sum(not c["passed"] for c in checks),
            }
        report["mismatches"] = [
            {"nct_id": r["nct_id"], "split": r["split"], **c}
            for r in report["records"]
            for c in r.get("checks", [])
            if not c["passed"]
        ]
        report["evaluation_status"] = (
            "passed" if report["overall"]["passed_cards"] == 10 else "failed"
        )
    except Exception as error:  # noqa: BLE001 -- preserve any first-run failure as evidence
        report["execution_error"] = {
            "type": type(error).__name__,
            "message": str(error),
        }
        report["evaluation_status"] = "error"
    finally:
        report["finished_at_utc"] = utc_now()
        report["duration_seconds"] = round(time.perf_counter() - timer, 6)
        write_new(output / "reference-evaluation.json", report)
    print(
        json.dumps(
            {
                "evaluation_status": report["evaluation_status"],
                "human_approval": "pending",
                "overall": report.get("overall"),
                "output": str(output / "reference-evaluation.json"),
            }
        )
    )
    return 0 if report["evaluation_status"] == "passed" else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True, type=Path)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--candidate-freeze", required=True, type=Path)
    parser.add_argument("--reference-sha256", required=True)
    return asyncio.run(execute(parser.parse_args()))


if __name__ == "__main__":
    raise SystemExit(main())
